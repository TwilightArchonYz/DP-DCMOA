function [xl,xu,fname,PF,M]=getFun(noPro,ft,nt,maxgen,preEvolution)
switch noPro
    case 1
        xl=-ones(1,10);
        xu=ones(1,10);
        xl(1)=0;
        M=2;
        fname='INSF1';
    case 2
        xl=-ones(1,10);
        xu=ones(1,10);
        xl(1)=0;
        M=2;
        fname='INSF2';
    case 3
        xl=-ones(1,10);
        xu=ones(1,10);
        xl(1)=0;
        M=2;
        fname='INSF3';
    case 4
        xl=-ones(1,10);
        xu=ones(1,10);
        xl(1)=0;
        M=3;
        fname='INSF4';
    case 5
        xl=-ones(1,10);
        xu=ones(1,10);
        xl(1)=0;
        M=3;
        fname='INSF5';
    case 6
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='INS1';M=2;xl(1)=0;
    case 7
        xl=zeros(1,12);
        xu=ones(1,12);
        fname='INS2';M=2;xl(1)=0;
    case 8
        xl=-ones(1,12);
        xu=1*ones(1,12);
        fname='INS3';M=2;xl(1)=0;
    case 9
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='INS4';M=2;xl(1)=0;
    case 10
        xl=zeros(1,12);
        xu=ones(1,12);
        fname='INS5';M=2;xl(1)=0;
    case 11
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='INS6';M=2;
    case 12
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='INS7';M=2;
    case 13
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='INS8';M=2;
    case 14
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='INS9';M=2;
        case 15
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='DCP1';M=2;xl(1)=0;
    case 16
        xl=zeros(1,12);
        xu=ones(1,12);
        fname='DCP2';M=2;xl(1)=0;
    case 17
        xl=-ones(1,12);
        xu=1*ones(1,12);
        fname='DCP3';M=2;xl(1)=0;
    case 18
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='DCP4';M=2;xl(1)=0;
    case 19
        xl=zeros(1,12);
        xu=ones(1,12);
        fname='DCP5';M=2;xl(1)=0;
    case 20
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='DCP6';M=2;
    case 21
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='DCP7';M=2;
    case 22
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='DCP8';M=2;
    case 23
        xl=-ones(1,12);
        xu=ones(1,12);
        fname='DCP9';M=2;
end
PF = GeneratePF(fname,ft,nt,maxgen,preEvolution);
end