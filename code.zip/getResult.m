function Result=getResult(numCE,Windows,FinalPop,PF)
%%
%preGen0=List_close(:,24:end);
preGen1=zeros(numCE,Windows);
D=zeros(numCE,Windows)+inf;
for gen1=2:numCE+1
    preGen=max(1,gen1-Windows):gen1-1;
    preGen=preGen(end:-1:1);
    preGen1(gen1-1,1:length(preGen))=preGen;
    for i=1:length(preGen)
        gen2=preGen(i);
        Pop1=FinalPop(gen1,:);
        Pop2=FinalPop(gen2,:);
        decs1=Pop1.decs;
        decs2=Pop2.decs;
        try
        D(gen1-1,i)=mean(min(pdist2(decs1,decs2)));
        catch
            a=1;
        end
    end
    index1=find(isinf(D(gen1-1,:))==1);
    index2=find(isinf(D(gen1-1,:))~=1);
    D(gen1-1,index1)=max(D(gen1-1,index2));
end
% gen=Windows+1:numCE+1;
%%
for i=1:length(D(:,1))
    %% 探究内容
    % 1 距当前环境最接近的环境的代数差值
    % 2 当前环境和历史最接近的环境的距离
    % 3 当前环境和前一环境的距离
    % 4
    temp=D(i,:);
    [minD,noGen]=min(temp);
    Result.CD(i)=D(i,1);
    Result.PD(i)=minD;
    Result.TG(i)=preGen1(i,noGen)-i+1;
end
Result.D=D;
Result.preGen1=preGen1;
% rng(1)
% colorStr=rand(length(PF),3)
% figure
% hold on
for gen=1:length(PF)
    turePF=PF(gen).PF;
    PopObj=FinalPop(gen,:).objs;
    % PopCons=FinalPop(gen,:).cons;
    % decs=FinalPop(gen,:).decs;
    hv(gen)=myHV(PopObj,turePF);
    igd(gen)=myIGD(PopObj,turePF);
    turePF=turePF+(gen-1);
    PopObj=PopObj+(gen-1);
    % plot(turePF(:,1),turePF(:,2),'.','MarkerFaceColor',colorStr(gen,:));
    % plot(PopObj(:,1),PopObj(:,2),'o','MarkerFaceColor',colorStr(gen,:));
end
Result.IGD=igd;
Result.HV=hv;
Result.MIGD=mean(igd);
Result.MHV=mean(hv);
end