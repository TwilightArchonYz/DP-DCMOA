function [Offspring1_dec,Pop1_Decs]=generateX_V(Offspring1_dec,Population1,p_success,N,V,Rn_STD)
    Pop1_Decs=Population1.decs;
    numV=floor(N*p_success);
    if numV>0
       Pop1_Decs=Pop1_Decs(1:numV,:);
       Pop1_Decs(1:numV,:)=Pop1_Decs(1:numV,:)+0.1*repmat(V,numV,1)+Rn_STD*randn(size(Pop1_Decs));
       Offspring1_dec(1:numV,:)=Pop1_Decs;
    else
        Pop1_Decs=[];
    end
end