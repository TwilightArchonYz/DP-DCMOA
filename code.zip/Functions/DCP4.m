classdef DCP4 < handle
% <problem> <NDCP>
% Dynamic MOP benchmark
% ft --- --- frequency of change
% nt --- --- severity of change
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = DCP4(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = DCP4;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
                y = (Dec(:,2:end)-0.5);
                g = 1 + sum((y.^2 - cos(pi*y) + 1).^2,2); 
                Obj(:,1) = g.*(Dec(:,1) + 0.25*sin(pi*Dec(:,1)));
                Obj(:,2) = g.*(1 - Dec(:,1) + 0.25*sin(pi*Dec(:,1)));
                
                %% calculate constraint violations
                G = 2 * floor(10*abs(mod(t+1,2)-1)+1e-4);
                c11 = (Obj(:,1)).^2 + (Obj(:,2)).^2 - (1.5 + 0.4*sin(4*atan(Obj(:,2)./Obj(:,1))).^16).^2;
                c12 = (Obj(:,1)).^2 + (Obj(:,2)).^2 - (1.3 - 0.45*sin(G*atan(Obj(:,2)./Obj(:,1))).^2).^2;
                Con = -c11.*c12;
%                 Obj = Obj +t ;
                
                %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)   
       %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            x1 = (0:1/(500-1):1)';
            pf1(:,1) = x1 +  0.25*sin(pi*x1);
            pf1(:,2) = 1- x1 +  0.25*sin(pi*x1);
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf=pf1;
                t  = (i-1) / nt;
                G = 2 * floor(10*abs(mod(t+1,2)-1)+1e-4);
                c11 = (pf(:,1)).^2 + (pf(:,2)).^2 - (1.5 + 0.4*sin(4*atan(pf(:,2)./pf(:,1))).^16).^2;
                c12 = (pf(:,1)).^2 + (pf(:,2)).^2 - (1.3 - 0.45*sin(G*atan(pf(:,2)./pf(:,1))).^2).^2;
                c1 = c11.*c12<0;
                pf(c1,:) = [];
                P(i) = struct('PF',pf);
            end 
        end
    end
end