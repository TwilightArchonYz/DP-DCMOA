classdef DCP3 < handle
% <problem> <NDCP>
% Dynamic MOP benchmark
% ft --- --- frequency of change
% nt --- --- severity of change
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = DCP3(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = DCP3;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
                G = abs(sin(0.5*pi*t));
                g = 1 + sum(sqrt(abs(Dec(:,2:end)-G)),2); 
                Obj(:,1) = g.*(Dec(:,1) )+ G^2;
                Obj(:,2) = g.*(1-Dec(:,1) )+ G^2;
                Obj(Obj < 1e-18) = 0;
                %% calculate constraint violations
                c1 = ( (Obj(:,1)-1).^2 + (Obj(:,2)-0.2).^2 - 0.3^2 ).* ( (Obj(:,2)-1).^2 + (Obj(:,1)-0.2).^2 - 0.3^2 );
                c2 = Obj(:,1).^2 + Obj(:,2).^2 - 4.^2;
                c3 = (Obj(:,1).^2 + Obj(:,2).^2 - (3.1 + 0.2*sin(4*atan(Obj(:,2)./Obj(:,1))).^2).^2) .* ((Obj(:,1)).^2 + (Obj(:,2)).^2 - (2.3).^2);
                Con = [-c1 c2 -c3];
                %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)   
       %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            x1 = (0:1/(500-1):1)';
            x2 = 0 : 0.001 : 2;
            pf2(:,1) = repmat(x2',2001,1);
            for i = 1 : 2001
                pf2(2001*(i-1)+1:2001*i,2) =  0.001 * (i-1);
            end
            cc = ( (pf2(:,1)-1).^2 + (pf2(:,2)-0.2).^2 - (0.3 ).^2 ).* ( (pf2(:,2)-1).^2 + (pf2(:,1)-0.2).^2 - (0.3 ).^2 );
            pf2(abs(cc) > 1e-3 ,:) = [];
            pf2(pf2(:,1)<1 & pf2(:,2)<1,:) = [];
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf=[];
                t  = (i-1) / nt;
                G = abs(sin(0.5*pi*t));
                P1 = x1 + G^2;
                P2 = 1-x1 + G^2;
                pf(:,1) = P1;
                pf(:,2) = P2;
                c1 = ( (pf(:,1)-1).^2 + (pf(:,2)-0.2).^2 - (0.3 ).^2 ).* ( (pf(:,2)-1).^2 + (pf(:,1)-0.2).^2 - (0.3 ).^2 ) < 0;
                pf(c1,:) = [];
                if size(pf,1) < length(x1)
                    pf22 =pf2;
                    pf22(pf22(:,1)<G^2 | pf22(:,2)<G^2,:) = [];
                    De = max(pf(:,1));
                    pf = [pf ;pf22];
                    if 2*De >= 2
                        Select = NDSort(-pf,1)~=1;
                        pf(Select,:) = [];
                    end
                    Select = NDSort(pf,1)~=1;
                    pf(Select,:) = [];
                end
                P(i) = struct('PF',pf);
            end 
        end
    end
end