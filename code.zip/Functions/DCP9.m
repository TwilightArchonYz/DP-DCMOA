classdef DCP9 < handle
% <problem> <NDCP>
% Dynamic MOP benchmark
% ft --- --- frequency of change
% nt --- --- severity of change
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = DCP9(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = DCP9;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
                G = abs(sin(0.5*pi*t));
                r = 1 + floor((D-1)*G);
                UnDec = Dec;
                UnDec(:,r) = [];
                g = 1 + 10*sum((UnDec-G).^2,2); 
                Obj(:,1) = g.*Dec(:,r);
                Obj(:,2) = g.*(1-Dec(:,r)) ;
                %% calculate constraint violations
                c11 = Obj(:,1).^2+ Obj(:,2).^2 - (0.2+G).^2;
                c12 = Obj(:,1).^(0.75+1.25*G) + Obj(:,2).^(0.75+1.25*G) - 4.^(0.75+1.25*G);
                c1 = c11.*c12;
                c21 = Obj(:,1).^2+ Obj(:,2).^2 - 1.6.^2;
                c22 = 2.1 - (Obj(:,1)./(1+0.15*cos(6*atan(Obj(:,2)./Obj(:,1)).^3).^10)).^2 - (Obj(:,2)./(1+0.75*cos(6*atan(Obj(:,2)./Obj(:,1)).^3).^10)).^2;
                c2 = c21.*c22;
                Con = [c1 c2];
%                 Obj = Obj+t;
                %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)   
       %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            x1 = (0:1/(501-1):1)';
            X = UniformPoint(500,2);
            pf1 = X./repmat(sqrt(sum(X.^2,2)),1,2);
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf=[];
                t = (i-1) / nt;
                G = sin(0.5*pi*t);
                pf(:,1) = x1 ;
                pf(:,2) = 1-x1;
                c1 = (pf(:,1)).^2+ (pf(:,2)).^2 - ((0.2+abs(G))).^2;
                pf(c1<0,:) = [];
                pf = [pf;(0.2+abs(G))*pf1];
                pf(NDSort(-pf,1)~=1,:) = [];
                P(i) = struct('PF',pf+0*t);
            end 
        end
    end
end