function PF = GeneratePF(Problem,ft,nt,maxgen,preEvolution,NS)
% True PF of DCF
% Problem --- --- the problem you want to sample
% ft --- --- Frequency of change
% nt --- --- Severity of change
% maxgen --- --- maximum generation
% preEvolution --- --- The maximum generation of first environment
% NS --- --- number of sampled points from PF
NS=1000;
switch Problem
    case 'INSF1'
        PF = INSF1.PF(ft,nt,maxgen,preEvolution);
    case 'INSF2'
        PF = INSF2.PF(ft,nt,maxgen,preEvolution);
    case 'INSF3'
        PF = INSF3.PF(ft,nt,maxgen,preEvolution);
    case 'INSF4'
        PF = INSF4.PF(ft,nt,maxgen,preEvolution);
    case 'INSF5'
        PF = INSF5.PF(ft,nt,maxgen,preEvolution);
    case 'INS1'
        PF = INS1.PF(ft,nt,maxgen,preEvolution);
    case 'INS2'
        PF = INS2.PF(ft,nt,maxgen,preEvolution);
    case 'INS3'
        PF = INS3.PF(ft,nt,maxgen,preEvolution);
    case 'INS4'
        PF = INS4.PF(ft,nt,maxgen,preEvolution);
    case 'INS5'
        PF = INS5.PF(ft,nt,maxgen,preEvolution);
    case 'INS6'
        PF = INS6.PF(ft,nt,maxgen,preEvolution);
    case 'INS7'
        PF = INS7.PF(ft,nt,maxgen,preEvolution);
    case 'INS8'
        PF = INS8.PF(ft,nt,maxgen,preEvolution);
    case 'INS9'
        PF = INS9.PF(ft,nt,maxgen,preEvolution);
    case 'DCP1'
        PF = DCP1.PF(ft,nt,maxgen,preEvolution);
    case 'DCP2'
        PF = DCP2.PF(ft,nt,maxgen,preEvolution);
    case 'DCP3'
        PF = DCP3.PF(ft,nt,maxgen,preEvolution);
    case 'DCP4'
        PF = DCP4.PF(ft,nt,maxgen,preEvolution);
    case 'DCP5'
        PF = DCP5.PF(ft,nt,maxgen,preEvolution);
    case 'DCP6'
        PF = DCP6.PF(ft,nt,maxgen,preEvolution);
    case 'DCP7'
        PF = DCP7.PF(ft,nt,maxgen,preEvolution);
    case 'DCP8'
        PF = DCP8.PF(ft,nt,maxgen,preEvolution);
    case 'DCP9'
        PF = DCP9.PF(ft,nt,maxgen,preEvolution);
end
end