classdef INS9 < handle
% <problem> <INS>
% Dynamic MOP benchmark                 % ft;  % the frequence of change
% nt;  % the severity of change         % gen; % the current generation
% maxgen; % the maxcurrent generation   % N;   % population size
% M;  % the multiobjective number       % D;   % the decision vector number
% boundary; % the boundary of decision vector  % dec;  % the decision vector
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = INS9(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = INS9;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
              Nt = 1 + floor(10*abs(sin(0.5*pi*t)));
              G = sin(0.5*pi*t);
              g = 1 + sum((Dec(:,2:end)- G.*Dec(:,1)).^2,2);

              Obj(:,1) = g.* (Dec(:,1) + max(0,(1/2/Nt+0.1)*sin(2*Nt*pi*Dec(:,1))));
              Obj(:,2) = g.* (1 - Dec(:,1) + max(0,(1/2/Nt+0.1)*sin(2*Nt*pi*Dec(:,1))));
              Obj = Obj + t;
              %% calculate constraint violations
                Con = zeros(size(Dec,1),1);
              %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)        
        %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            Dec = (0:1/(1000-1):1)';
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf = [];
                t  = (i-1) / nt;
                P1 = Dec;
                Nt = 1 + floor(10*abs(sin(0.5*pi*t)));
                interval = 0 : 2*Nt-1;
                interval = interval/2/Nt;
                for j = 1 : Nt
                    P1(P1>(interval(2*j-1)) & P1<(interval(2*j))) = [];
                end
                P2 = 1 - P1;
                pf(:,1) = P1 ;
                pf(:,2) = P2 ;
                P(i) = struct('PF',pf + t);
            end 
        end
    end
end