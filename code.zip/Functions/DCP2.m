classdef DCP2 < handle
% <problem> <NDCP>
% Dynamic MOP benchmark
% ft --- --- frequency of change
% nt --- --- severity of change
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = DCP2(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = DCP2;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
                G = sin(0.5*pi*t);
                g = 1 + sum((Dec(:,2:end)- G).^2 + sin((Dec(:,2:end)- G)*0.5*pi).^2,2);
                Obj(:,1) = g.*(Dec(:,1) + 0.25*G*sin(pi*Dec(:,1)));
                Obj(:,2) = g.*(1-Dec(:,1) + 0.25*G*sin(pi*Dec(:,1)));
                Obj(Obj < 1e-18) = 0;
                %% calculate constraint violations
                c1 = (4*Obj(:,1) + Obj(:,2) -1).*(0.3*Obj(:,1) + Obj(:,2) -0.3);
                c2 = (Obj(:,1) + Obj(:,2) -1.3).*(1.85 - Obj(:,2) - Obj(:,1) - (0.3*sin(3*pi*(Obj(:,2)-Obj(:,1)))).^2 );
                Con = [-c1 c2];
                %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)   
       %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            x2 = 0 : 0.001 : 2;
            pf2(:,1) = repmat(x2',2001,1);
            for i = 1 : 2001
                pf2(2001*(i-1)+1:2001*i,2) =  0.001 * (i-1);
            end
            cc = (1.85 - pf2(:,2) - pf2(:,1) - (0.3*sin(3*pi*(pf2(:,2)-pf2(:,1)))).^2 );
            pf2(abs(cc) > 2e-3,:) = [];
            x1 = (0:1/(500-1):1)';
            y21 = 1 - 4*x1(x1<0.1891); y22 = 0.3 - 0.3*x1(x1>=0.1891);
            y = [x1 [y21;y22]];
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf=[];
                t  = (i-1) / nt;
                G = sin(0.5*pi*t);
                P1 = x1 + 0.25*G*sin(pi*x1);
                P2 = 1-x1 + 0.25*G*sin(pi*x1);
                c1 = (4*P1 + P2 -1).*(0.3*P1 + P2 -0.3)<0;
                c2 = (P1 + P2 -1.3).*(1.85 - P2 - P1 - (0.3*sin(3*pi*(P2-P1))).^2 ) >0;
                pf(:,1) = P1;   pf(:,2) = P2;
                pf(c1 | c2,:) = [];
                pf = [pf;y];
                Select = NDSort(-pf,1)~=1;
                pf(Select,:) = []; [~,MinPF]=min(pf(:,1)); pf(MinPF,1) = 0;
                [~,MinPF]=min(pf(:,2)); pf(MinPF,2) = 0;
                pf = [pf;pf2];
                pf(NDSort(pf,1)~=1,:) = [];
                P(i) = struct('PF',pf);
            end 
        end
    end
end