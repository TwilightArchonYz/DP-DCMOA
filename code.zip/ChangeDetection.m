function [change,NewCurrent] = ChangeDetection(Population,Problem,ft,nt,gen,preEvolution,maxgen)
% Dectect the change
    
%     N = size(Population,2);
%     X = randperm(N);
%     Current = Population(X(1:round(0.1*N)));
    Dec = Population.decs;
    NewCurrent = Individual(Problem,ft,nt,gen,[],preEvolution,Dec);
    obj1 = Population.objs;
    obj2 = NewCurrent.objs;
    change = mean(sum(abs(obj1-obj2),2));
end