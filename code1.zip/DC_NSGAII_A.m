
function Population = D_NSGAII_A(Mode,Problem,boundary,N,maxgen,ft,nt,preEvolution)
%% 种群初始化
Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1)); %个体
Population1 = Individual(Problem,ft,nt,1,N,preEvolution,Dec);    %目
Population=[Population1];
[~,FrontNo,CrowdDis] = DNSGAIIEnvironment(Population,N);
%%
gen = 1;
number = 1;
fes=N;
jishu=1;
%% Optimization
while maxgen > gen
    MatingPool    = TournamentSelection(2,N,FrontNo,-CrowdDis);
    Offdec        = GA(Population(number,MatingPool).decs,boundary);
    [Offspring,~] = Individual(Problem,ft,nt,gen,[],preEvolution,Offdec);
    [Population(number,:),FrontNo,CrowdDis] = DNSGAIIEnvironment([Population(number,:),Offspring],N);
    long=randperm(N);
    long_index1=long(1:8);
    gen=gen+1;
    [change,NewCurrent] = ChangeDetection(Population(number,long_index1),Problem,ft,nt,gen,preEvolution,maxgen);
    flag=0;
    fes=fes+8;
    

    if change > 0.00001
        Dec = unifrnd(repmat(boundary.lower,round(0.2*N),1),repmat(boundary.upper,round(0.2*N),1));
        randPop = Individual(Problem,ft,nt,gen,[],preEvolution,Dec);
        long = randperm(N);
        pastPop = Individual(Problem,ft,nt,gen,[],preEvolution,Population(number,long(1:N-round(0.2*N))).decs);
        [Population1,FrontNo,CrowdDis] = DNSGAIIEnvironment([randPop,pastPop],N);
    end
        %%
    % Add new population of next change
    if gen-preEvolution+1 > 0
        if ~mod(gen-preEvolution,ft)
            number = floor((gen-preEvolution)/ft)+2;   
            Population(number,:) = [Population1];
        end
    end
    if flag==1
        gen=gen+xs;
    end
end
% disp(fes)
% disp(gen*100)
Population(end,:)=[];
end

