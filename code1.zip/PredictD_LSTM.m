function DD_Pre = PredictD_LSTM(D_List, Windows)
    % 数据预处理
    data_P = D_List(2 * Windows + 1:end, :);  % 截取数据
    PS_max = max(max(data_P));  % 最大值
    PS_min = min(min(data_P));  % 最小值
    data_P = (data_P - PS_min) / (PS_max - PS_min);  % 归一化
    data_P = (data_P - 0.5) * 2;  % 数据缩放到 [-1, 1]
    [data_P, PS] = mapminmax(data_P);  % 使用 mapminmax 归一化

    % 准备训练数据
    data_P_train_x = data_P(1:end-1, :);  % 特征数据
    data_P_train_y = data_P(2:end, :);  % 目标数据
    data_P_test_x = data_P(end, :);  % 测试数据（预测最后一个数据点）


    % LSTM 网络架构设置
    numFeatures = size(data_P_train_x, 2);  % 输入特征的数量
    numResponses = size(data_P_train_y, 2);  % 输出的数量


    % 转换为单元格数组
    XTrain = num2cell(data_P_train_x', 1);  % 转换为列向量的单元格数组
    XTest = num2cell(data_P_test_x', 1);    % 转换为列向量的单元格数组
    YTrain = data_P_train_y;
    % 创建 LSTM 网络层
    layers = [
        sequenceInputLayer(numFeatures, 'Name', 'input')  % 确保特征维度为 9
        lstmLayer(50, 'OutputMode', 'last', 'Name', 'LSTM')
        fullyConnectedLayer(numResponses, 'Name', 'fc')
        regressionLayer('Name', 'output')
    ];

    % LSTM 网络训练选项
    options = trainingOptions('adam', ...
        'MaxEpochs', 100, ...
        'MiniBatchSize', 20, ...
        'InitialLearnRate', 0.001, ...
        'Shuffle', 'never', ...
        'Verbose', 0, ...
        'Plots', 'none');

    % 训练 LSTM 网络
    net = trainNetwork(XTrain, YTrain, layers, options);

    % 对测试数据进行预测（需要格式化）
    %XTest = reshape(data_P_test_x, numFeatures, 1, numFeatures,[]);  % 测试数据需要相同格式
    YPred = predict(net, XTest);

    % 反归一化到原始数据范围
    YPred = YPred / 2 + 0.5;  % 反缩放
    YPred = YPred * (PS_max - PS_min) + PS_min;  % 反归一化

    % 输出预测值
    DD_Pre = YPred;
end
