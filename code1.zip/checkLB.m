function Offspring2_dec=checkLB(Offspring2_dec,boundary)
    for i=1:length(Offspring2_dec(:,1))
        FLAG=Offspring2_dec(i,:)>boundary.upper;
        Offspring2_dec(i,FLAG)=boundary.upper(FLAG);
        if sum(FLAG)~=0
            a=1;
        end
        FLAG=Offspring2_dec(i,:)<boundary.lower;
        Offspring2_dec(i,FLAG)=boundary.lower(FLAG);
        if sum(FLAG)~=0
            a=1;
        end
    end
end