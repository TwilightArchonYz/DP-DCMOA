
function Population = D_IMTCMO_PV_LSTM(Mode,Problem,boundary,N,maxgen,ft,nt,preEvolution)
% rand('state',sum(100*clock));
% rng('default')
% rng(1)
% <algorithm> <D>
% Nondominated sorting genetic algorithm II --- DNSGAII
%% Generate random population

%[Population] = Individual(fname,ft,nt,1,N,preEvolution,maxgen);

% Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
% Population = Individual(Problem,ft,nt,1,N,preEvolution,Dec,maxgen);
% Zmin       = min(Population.objs,[],1);
% Fmin       = min(Population(all(Population.cons<=0,2)).objs,[],1);

% Ra         = 1;

%% 种群初始化
Dec = unifrnd(repmat(boundary.lower,N/2,1),repmat(boundary.upper,N/2,1)); %个体
Population1 = Individual(Problem,ft,nt,1,N/2,preEvolution,Dec);    %目标
Fitness1    = CalFitness(Population1.objs,Population1.cons);              %适应度值
Zmin1       = min(Population1.objs,[],1);

Dec = unifrnd(repmat(boundary.lower,N/2,1),repmat(boundary.upper,N/2,1));
Population2 = Individual(Problem,ft,nt,1,N/2,preEvolution,Dec);
Fitness2   = CalFitness(Population2.objs,Population2.cons);
Zmin2       = min(Population2.objs,[],1);

%%
M = length(Zmin1); %目标数量
%W = UniformPoint(N,M);
%%
cons = [Population1.cons;Population2.cons]; %约束
cons(cons<0) = 0;
VAR0 = max(sum(cons,2));
if VAR0 == 0
    VAR0 = 1;
end
X=0;

Population=[Population1,Population2];
%[~,FrontNo,CrowdDis] = DNSGAIIEnvironment(Population,N);
gen = 1;
number = 1;
fes=N;
jishu=1;
Windows=10;
%%
p_success=0;
V=0;
Rn_STD=0;
%% Optimization
while maxgen > gen
    %% Udate the epsilon value
    cp=(-log(VAR0)-6)/log(1-0.5);
    VAR = VAR0*(1-X)^cp;

    %% Offspring generation
    MatingPool = [Population1(randsample(N/2,N/2))];
    [Mate1,Mate2,Mate3]  = Neighbor_Pairing_Strategy(MatingPool,Zmin1);
    Offspring1_dec(1:N/4,:)= OperatorDE_rand_1(boundary,Mate1(1:N/4), Mate2(1:N/4), Mate3(1:N/4));
    Offspring1_dec(1+N/4:N/2,:) = OperatorDE_pbest_1_main(Population1, N/4, boundary, Fitness1, 0.1);
    [Offspring1_dec,Pop1_Decs]=generateX_V(Offspring1_dec,Population1,p_success,N/2,V,Rn_STD);
    Offspring1_dec=checkLB(Offspring1_dec,boundary);
    Offspring1=Individual(Problem,ft,nt,gen,N/2,preEvolution,Offspring1_dec);

    MatingPool = [Population2(randsample(N/2,N/2))];
    [Mate1,Mate2,Mate3]  = Neighbor_Pairing_Strategy(MatingPool,Zmin2);
    Offspring2_dec(1:N/4,:)= OperatorDE_rand_1(boundary,Mate1(1:N/4), Mate2(1:N/4), Mate3(1:N/4));
    Offspring2_dec(1+N/4:N/2,:) = OperatorDE_pbest_1_main(Population2, N/4, boundary, Fitness2, 0.1);
    [Offspring2_dec,Pop2_Decs]=generateX_V(Offspring2_dec,Population2,p_success,N/2,V,Rn_STD);
    Offspring2_dec=checkLB(Offspring2_dec,boundary);
    Offspring2=Individual(Problem,ft,nt,gen,N/2,preEvolution,Offspring2_dec);

    Zmin1       = min([Zmin1;Offspring1.objs],[],1);
    Zmin2       = min([Zmin2;Offspring2.objs],[],1);

    %% Environmental selection
    [Population1,Fitness1] = Main_task_EnvironmentalSelection([Population1,Offspring1,Offspring2], N/2, true);
    %[Population2,Fitness2] = Main_task_EnvironmentalSelection([Population2,Offspring1,Offspring2], N/2, true);
    [Population2,Fitness2] = Auxiliray_task_EnvironmentalSelection([Population2,Offspring2,Offspring1], N/2, VAR);
    Population0=Main_task_EnvironmentalSelection([Population(number,:),Population1,Population2,Offspring1,Offspring2], N, true);
    
    %% 计算成功率
    if ~isempty(Pop1_Decs)
        P1_Decs=Population0.decs;
        flag=ismember([Pop1_Decs;Pop2_Decs],P1_Decs,"rows");
        p_success=mean(flag)*(ft-jishu)/ft;
        %disp([jishu,p_success]);
    end
    
    Population(number,:)=Population0;
    if gen<preEvolution
        X=X+1/(preEvolution/gen);
    else
        X=X+1/(ft/jishu);
    end

    jishu=jishu+1;
    fes=fes+N;
    Centroid   = mean(Population0.decs,1);

    if Mode == 1
        DrawPop(Population.objs,Problem,ft,nt);
    end
    gen = gen + 1;
    N1=ceil(N*0.4);
    N2=ceil(N*0.4);
    N3=N-N1-N2;
    long=randperm(N);
    long_index1=long(1:8);
    long_index2=long(9:9+N3-1);
    long_index3=long(9+N3+1:end);
    [change,NewCurrent] = ChangeDetection(Population(number,long_index1),Problem,ft,nt,gen,preEvolution,maxgen);
    flag=0;
    fes=fes+8;

    if change > 0.00001 || (gen>=preEvolution && ~mod(gen-preEvolution,ft))
        %disp(gen)
        %Population(number,:)=Population1;
        if number>1
            D_List0=zeros(1,2*Windows)+inf;
            nowT=number;
            preT=1:number-1;
            preT=preT(max(1,end-2*Windows+1):end);
            preT=preT(end:-1:1);
            Decs_nowT=Population(number,:).decs;
            for i=1:length(preT)
                Decs_preT=Population(preT(i),:).decs;
                D_List0(i)=mean(min(pdist2(Decs_nowT,Decs_preT)));
            end
            D_List(number-1,:)=D_List0;
        end
        flag=1;
        jishu=1;
        nowT=length(Population(:,1)); %当前记录的次数
        preT=nowT-Windows*2:nowT-1;
        preT(preT<=0)=[];

        if nowT<=Windows
            xs=0;
            %
            RP_Population=Individual(Problem,ft,nt,gen,[],preEvolution,Population(number,long_index2).decs);
            pastPop = NewCurrent;
            tempPop=[pastPop,RP_Population];
            [Dec,V,Rn_STD]=generateX(tempPop,Centroid,N,boundary);
            randPop = Individual(Problem,ft,nt,gen,[],preEvolution,Dec);
            %[Population0,Population1] = ICMA_Update([randPop,tempPop],N,W,Zmin,Fmin);
            [Population1,Fitness1] = Main_task_EnvironmentalSelection([randPop,tempPop], N/2, true);
            [Population2,Fitness2] = Main_task_EnvironmentalSelection([randPop,tempPop], N/2, true);
            %[Population2,Fitness2] = Auxiliray_task_EnvironmentalSelection([randPop,tempPop], N/2, true);
            fes=fes+(xs+1)*N;
        else
            xs=1;
            if nowT<=3*Windows
                DD=D_List(preT(end-Windows+1:end),1:length(preT));
                % D_List 第1行记录的是 时刻2和时刻1的距离
                %        第nowT-1行记录的是 时刻nowT和时刻nowT-1的距离
                DD(isinf(DD))=max(max(DD(~isinf(DD))));
                DD_Pre=mean(DD);  %预测的第nowT行记录，即时刻nowT+1和时刻nowT的距离
            else
                DD_Pre=PredictD_LSTM(D_List,Windows);
            end
            SN=calSN(DD_Pre,N); %每一代的采样数
            SN=SN(end:-1:1);
            index0=[];

            for i=1:length(preT)
                index1=[];
                if i==length(preT)
                    index1=[long_index3*0+preT(i)+1;long_index3]';
                else
                    for j=1:N
                        index1=[index1;preT(i)+1,j];
                    end
                end
                ind=randperm(length(index1(:,1)),SN(i));
                index0=[index0;index1(ind,:)];
            end
            % index00=index0;
            % index0=[];
            % for i=1:length(index)
            %     if i==1
            %         for j=1:length(long_index3)
            %             index0=[index0;index(i),long_index3(j)];
            %         end
            %     else
            %
            %         for j=1:N
            %             index0=[index0;index(i),j];
            %         end
            %     end
            % end
            % ind=randperm(length(index0(:,1)),N);
            % index0=index0(ind,:);
            for i=1:N
                RP_Population1(1,i)=Population(index0(i,1),index0(i,2));
            end
            RP_Population1= Individual(Problem,ft,nt,gen,[],preEvolution,RP_Population1.decs);
            RP_Population= Individual(Problem,ft,nt,gen,[],preEvolution,Population(number,long_index2).decs);
            pastPop = NewCurrent;
            tempPop=[pastPop,RP_Population,RP_Population1];
            %Dec=generateX(tempPop,Centroid,N*2,boundary);
            [Dec,V,Rn_STD]=generateX(tempPop,Centroid,N*2,boundary);
            randPop = Individual(Problem,ft,nt,gen,[],preEvolution,Dec);

            [Population1,Fitness1] = Main_task_EnvironmentalSelection([randPop,pastPop,RP_Population,RP_Population1], N/2, true);
            %[Population2,Fitness2] = Auxiliray_task_EnvironmentalSelection([randPop,pastPop,RP_Population,RP_Population1], N/2, true);
            [Population2,Fitness2] = Main_task_EnvironmentalSelection([randPop,pastPop,RP_Population,RP_Population1], N/2, true);
            %[newPopulation,FrontNo,CrowdDis] = DNSGAIIEnvironment([randPop,pastPop,RP_Population,RP_Population1],N);
            fes=fes+2*N;
        end
        %%

        %% 计算成功率
        P1_Decs=Population1.decs;
        flag0=ismember(Dec,P1_Decs,"rows");
        p_success=mean(flag0);
    end
    % Add new population of next change
    if gen-preEvolution+1 > 0
        if ~mod(gen-preEvolution,ft)
            number = floor((gen-preEvolution)/ft)+2;
            Population(number,:) = [Population1,Population2];
            X=0;
        end
    end
    if flag==1
        gen=gen+xs;
    end
end
% disp(fes)
% disp(gen*100)
Population(end,:)=[];
end

