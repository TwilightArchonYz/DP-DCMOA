function DD0=calSN(DD,N)
    DD0=max(DD)-DD+0.01;
    DD0=ceil(N*DD0/sum(DD0));
    while sum(DD0)>N
        [~,p]=max(DD0);
        DD0(p)=DD0(p)-1;
    end
end