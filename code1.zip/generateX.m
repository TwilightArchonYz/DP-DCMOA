function [Dec,V,Rn_STD]=generateX(tempPop,Centroid,N,boundary)
    [newPopulation,FrontNo,CrowdDis] = DNSGAIIEnvironment(tempPop,length(tempPop));
    tempArch=newPopulation(FrontNo==1);
    Ct = mean(tempArch.decs,1);
    St = norm(Ct-Centroid);
    CA = mean(tempArch.decs,1);
    remain = ~Truncation(newPopulation.objs,ceil(length(newPopulation)/2));
    CR = mean(newPopulation(remain).decs,1);
    X  = newPopulation(~remain).decs;
    V  = repmat(St.*(CA-CR)./norm(CA-CR),size(X,1),1);
    X  = X + 0.1*V + randn(size(X)).*St/2/sqrt(size(X,2));
    V  = V(1,:);
    Rn_STD=St/2/sqrt(size(X,2));
    numX=length(X(:,1));
    for i=1:numX
        index=X(i,:)<boundary.lower;
        X(i,index)=boundary.lower(index);
        index=X(i,:)>boundary.upper;
        X(i,index)=boundary.upper(index);
    end
    
    N1=N-numX-length(newPopulation);
    % 生成新个体
    Dec = unifrnd(repmat(boundary.lower,N1,1),repmat(boundary.upper,N1,1));
    Dec = [Dec;X];
end
function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

    %% Truncation
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end