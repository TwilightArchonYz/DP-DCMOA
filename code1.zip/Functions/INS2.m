classdef INS2 < handle
% <problem> <INS>
% Dynamic MOP benchmark                 % ft;  % the frequence of change
% nt;  % the severity of change         % gen; % the current generation
% maxgen; % the maxcurrent generation   % N;   % population size
% M;  % the multiobjective number       % D;   % the decision vector number
% boundary; % the boundary of decision vector  % dec;  % the decision vector
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = INS2(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = INS2;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
                G = abs(sin(0.5*pi*t));
                r = 1 + floor((D-1)*G);
                UnDec = Dec;
                UnDec(:,r) = [];
                g = 1 + sum((UnDec-G).^2,2);  
                h = 1 - Dec(:,r).^0.5;
                Obj(:,1) = g.*Dec(:,r);
                Obj(:,2) = g.*h;
                Obj = Obj + t;
              %% calculate constraint violations
                Con = zeros(size(Dec,1),1);
              %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)        
        %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            V(:,1) = (0:1/(500-1):1)';
            V(:,2) = 1 - V(:,1).^0.5;
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf=[];
                pf = V;
                t  = (i-1) / nt;
                P(i) = struct('PF',pf+t);
            end 
        end
    end
end