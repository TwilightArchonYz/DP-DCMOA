function [Population,boundary,V,N] = Individual(Problem,ft,nt,gen,N,preEvolution,Dec,AddProper)
% Generate Population of various problems
% Problem list: FDA  DMOP  JY  UDF
    switch Problem
        case 'INS1'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = ones(1,D);
            if nargin == 7
                Population = INS1(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS1(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS1(ft,nt,gen,Dec,preEvolution);
            end
        case 'INS2'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = zeros(1,D);
            boundary.upper  = ones(1,D);
            if nargin == 7
                Population = INS2(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS2(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS2(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS3'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,2*ones(1,D-1)];
            if nargin == 7
                Population = INS3(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS3(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS3(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS4'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = ones(1,D);
            if nargin == 7
                Population = INS4(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS4(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS4(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS5'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INS5(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS5(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS5(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS6'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INS6(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS6(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS6(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS7'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INS7(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS7(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS7(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS8'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INS8(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS8(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS8(ft,nt,gen,Dec,preEvolution);
            end
         case 'INS9'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INS9(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INS9(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INS9(ft,nt,gen,Dec,preEvolution);
            end
        %% finalist
         case 'INSF1'
            M = 2;      D = 12;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INSF1(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INSF1(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INSF1(ft,nt,gen,Dec,preEvolution);
            end
         case 'INSF2'
            M = 2;      D = 12;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-2];
            boundary.upper  = [1,2*ones(1,D-1)];
            if nargin == 7
                Population = INSF2(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INSF2(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INSF2(ft,nt,gen,Dec,preEvolution);
            end
         case 'INSF3'
            M = 2;      D = 12;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = INSF3(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INSF3(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INSF3(ft,nt,gen,Dec,preEvolution);
            end
         case 'INSF4'
            M = 2;      D = 12;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-2];
            boundary.upper  = [1,2*ones(1,D-1)];
            if nargin == 7
                Population = INSF4(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INSF4(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INSF4(ft,nt,gen,Dec,preEvolution);
            end
         case 'INSF5'
            M = 2;      D = 12;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-2];
            boundary.upper  = [1,2*ones(1,D-1)];
            if nargin == 7
                Population = INSF5(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = INSF5(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = INSF5(ft,nt,gen,Dec,preEvolution);
            end
                    case 'DCP1'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = ones(1,D);
            if nargin == 7
                Population = DCP1(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP1(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP1(ft,nt,gen,Dec,preEvolution);
            end
        case 'DCP2'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = zeros(1,D);
            boundary.upper  = ones(1,D);
            if nargin == 7
                Population = DCP2(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP2(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP2(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP3'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,2*ones(1,D-1)];
            if nargin == 7
                Population = DCP3(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP3(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP3(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP4'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = ones(1,D);
            if nargin == 7
                Population = DCP4(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP4(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP4(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP5'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = DCP5(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP5(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP5(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP6'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = DCP6(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP6(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP6(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP7'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = DCP7(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP7(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP7(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP8'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = DCP8(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP8(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP8(ft,nt,gen,Dec,preEvolution);
            end
         case 'DCP9'
            M = 2;      D = 10;
            [V,N] = UniformPoint(N,M);
            boundary.lower  = [0,zeros(1,D-1)-1];
            boundary.upper  = [1,ones(1,D-1)];
            if nargin == 7
                Population = DCP9(ft,nt,gen,Dec,preEvolution);
            elseif nargin == 8
                Population = DCP9(ft,nt,gen,Dec,preEvolution,AddProper);
            else
                % Generate initial population
                Dec = unifrnd(repmat(boundary.lower,N,1),repmat(boundary.upper,N,1));
                Population = DCP9(ft,nt,gen,Dec,preEvolution);
            end
    end
end