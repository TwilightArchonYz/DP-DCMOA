classdef DCP8 < handle
% <problem> <NDCP>
% Dynamic MOP benchmark
% ft --- --- frequency of change
% nt --- --- severity of change
    properties(SetAccess = private)
        obj;  % the objective value
        dec;  % the decision vector
        con;  % the constraint violations
        add;  % Additional properties of the individual
    end
    methods
        %% Initialization
        function obj = DCP8(ft,nt,gen,Dec,preEvolution,AddProper)
            if nargin > 0
                [N,D] = size(Dec);
                obj(1,N) = DCP8;
              %% calculate objective value
              if gen < preEvolution
                t = 0;
              else
                t = floor((gen-preEvolution)/ft+1)* 1/nt;
              end
                G = sin(0.5*pi*t);
                y = (Dec(:,2:end)-G);
                g = 1 + sum((abs(G)*y.^2 - cos(pi*y) +1).^2,2);
                Obj(:,1) = g.*Dec(:,1);
                Obj(:,2) = g.*(1-Dec(:,1));
                %% calculate constraint violations
                c11 = (Obj(:,1)).^1.5+ (Obj(:,2)).^1.5 - 1.2^1.5;
                c12 = Obj(:,1).^(0.5) + Obj(:,2).^(0.5) - (0.95+0.5*abs(G) );
                c21 =  0.8*Obj(:,1) + Obj(:,2) - (2.5 + 0.08*sin(2*pi*(Obj(:,2)-Obj(:,1))));
                c22 = (0.93 + abs(G)/3)*Obj(:,1) + Obj(:,2) - (2.7+abs(G)/2 + 0.08*sin(2*pi*(Obj(:,2)-Obj(:,1))));
                c1  = c11.*c12;
                c2  = c21.*c22;
                Con = -[c1 c2];
%                 Obj = Obj+2*t;
                %% generate population
                for i = 1 : length(obj)
                    obj(i).dec = Dec(i,:);
                    obj(i).obj = Obj(i,:);
                    obj(i).con = Con(i,:);
                end
                if nargin > 5
                    for i = 1 : length(obj)
                        obj(i).add = AddProper(i,:);
                    end
                end
            end
        end
          %% Get the matrix of decision variables of the population
        function value = decs(obj)
        %decs - Get the matrix of decision variables of the population.
            value = cat(1,obj.dec);
        end
        %% Get the matrix of objective values of the population
        function value = objs(obj)
        %objs - Get the matrix of objective values of the population.
            value = cat(1,obj.obj);
        end
        %% Get the matrix of constraint violations of the population
        function value = cons(obj)
        %cons - Get the matrix of constraint violations of the population.
            value = cat(1,obj.con);
        end
        function value = adds(obj,AddProper)
        %adds - Get the matrix of additional properties of the population.
            for i = 1 : length(obj)
                if isempty(obj(i).add)
                    obj(i).add = AddProper(i,:);
                end
            end
            value = cat(1,obj.add);
        end
    end
    methods (Static)   
       %% Sample reference points on Pareto front
        function P = PF(ft,nt,maxgen,preEvolution)
            x1 = (0:1/(501-1):1)';
            X = UniformPoint(500,2);
            pf1 = 1.2* X./repmat((sum(X.^1.5,2)).^(2/3),1,2);
            for i = 1 : ceil((maxgen-preEvolution)/ft+1)
                pf=[];
                t = (i-1) / nt;
                G = sin(0.5*pi*t);
                pf(:,1) = x1 ;
                pf(:,2) = 1-x1;
                c1 = pf(:,1).^(0.5) + pf(:,2).^(0.5) - (0.95+0.5*abs(G) );
                pf(c1>0,:) = [];
                pf = [pf;pf1];
                pf(NDSort(pf,1)~=1,:) = [];
                P(i) = struct('PF',pf+0*t);
            end 
        end
    end
end