%% 2024.9.21
clc
clear all
close all
global calculateCount
global flag;
calculateCount = 0;
flag = false;
addpath('Functions')
%%

popsize = 100;                 % 种群规模 (Population size)
ft = 10;                       % 变化间隔 (Change interval)
nt = 5;                        % 变化强度 (Change intensity)
preEvolution = 60;             % 预优化迭代代数 (Pre-optimization iteration count)

Windows = 10;                  % 时间窗 (Time window)
Algorithm = [{@DP_DCMOA_PV_LSTM},{@DP_DCMOA_PV_SVM}, {@DP_DCMOA_V}, {@DC_NSGAII_A}]; 
% DP_DCMOA_PV_SVM  V7
% DP_DCMOA_V      V6
Problem = [1:22];              % 测试函数编号 (Test function numbers) 
% 注：共23个测试函数，第23个测试函数存在问题 (Note: 23rd test function has issues)
numRep = 2;                   % 重复实验次数 (Number of repeat experiments)

%% 生成随机数种子 (并行计算专用，其他方法在并行时无法保证结果复现) 
% Generate random number seeds (for parallel computation, ensures result reproducibility)
rng('default')
mainSeed = 1;
% 创建一个随机数流对象 (Create a random number stream object)
stream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, numRep);
for i = 1:numRep
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end

%% 环境参数 (Environment parameters)
ParaMeters0 = [
    10, 5;
    10, 10;
    20, 5;
    20, 10;
    ];

ParaMeters = [];
for noPro0 = 1:length(Problem)
    noPro = Problem(noPro0);
    for j = 1:length(ParaMeters0(:,1))
        ParaMeters = [ParaMeters; noPro, ParaMeters0(j,:)];
    end
end

%% 重复实验 (Repeat experiments)
% delete(gcp('nocreate')); % 删除现有并行池 (Delete any existing parallel pool)
% parpool(10); % 启动并行池 (Start parallel pool with 10 workers)
for noP = 1:length(ParaMeters(:,1))
    noPro = ParaMeters(noP, 1);
    ft = ParaMeters(noP, 2);                     % 变化间隔 (Change interval)
    nt = ParaMeters(noP, 3);                     % 变化强度 (Change intensity)
    numCE = 100;                                 % 环境变化次数 (Number of environment changes)
    maxgen = preEvolution + ft * 100;            % 总迭代次数 (Total iterations)
    maxFes = maxgen * popsize;                   % 最大评价次数 (Maximum function evaluations)
    
    % 获得函数参数 (Obtain function parameters)
    [~, ~, fname, PF] = getFun(noPro, ft, nt, maxgen, preEvolution);
    [~, boundary, ~, ~] = Individual(fname, ft, nt, 1, popsize, preEvolution);
    
    %% 调用算法 (Call algorithms)
    for noA = 1:length(Algorithm)
        for noRng = 1:numRep
            % 获取当前迭代的随机数流 (Get the current iteration's random number stream)
            currentStream = seeds{noRng};
            % 设置当前工作者的随机数流 (Set the current worker's random number stream)
            RandStream.setGlobalStream(currentStream);
            tic;
            % 调用对应算法并存储最终种群 (Call the corresponding algorithm and store final population)
            FinalPop{noA, noRng} = Algorithm{noA}(2, fname, boundary, popsize, maxgen, ft, nt, preEvolution);
            runtime(noA, noRng) = toc;  % 记录算法运行时间 (Record algorithm runtime)
        end
    end
    
    %% 计算结果 (Calculate results)
    for noA = 1:length(Algorithm)
        for noRng = 1:numRep
            tempResult(noA, noRng) = getResult(numCE, Windows, FinalPop{noA, noRng}, PF);
        end
    end
    
    Result.data{noP} = tempResult;
    Result.runtime{noP} = runtime;
    
    % 计算平均值 (Calculate averages)
    for noA = 1:length(Algorithm)
        for noRng = 1:numRep
            MHV(noA, noRng) = tempResult(noA, noRng).MHV;  % 计算MHV (Calculate MHV)
            MIGD(noA, noRng) = tempResult(noA, noRng).MIGD;  % 计算MIGD (Calculate MIGD)
        end
    end
    
    meanHV(noP, :) = mean(MHV');  % 平均MHV (Average MHV)
    meanIGD(noP, :) = mean(MIGD');  % 平均MIGD (Average MIGD)
end

%% 计算所有实验的平均值 (Calculate averages for all experiments)
for noP = 1:length(ParaMeters(:, 1))
    tempResult = Result.data{noP};
    for noA = 1:length(Algorithm)
        for noRng = 1:numRep
            MHV(noA, noRng) = tempResult(noA, noRng).MHV;  % 计算MHV (Calculate MHV)
            MIGD(noA, noRng) = tempResult(noA, noRng).MIGD;  % 计算MIGD (Calculate MIGD)
        end
    end
    meanHV(noP, :) = mean(MHV');  % 平均MHV (Average MHV)
    meanIGD(noP, :) = mean(MIGD');  % 平均MIGD (Average MIGD)
end

Result.meanHV = meanHV;
Result.meanIGD = meanIGD;
